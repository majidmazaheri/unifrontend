export class Plant {
    public p_id: Number[];
    public name: string[];
    public e_s_moisture: number;
    public e_light: number;
    public e_a_moisture: number;
    public e_temp: number;
    public desc: string[];
  } 